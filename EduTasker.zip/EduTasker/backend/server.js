require("dotenv").config(); // Load .env variables
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

// Database connection using .env variables
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

db.connect((err) => {
  if (err) {
    console.error("Database connection failed:", err);
    return;
  }
  console.log("Connected to MySQL");
});

// Authentication Routes (Login and Register)
app.post("/api/register", (req, res) => {
  const { username, password } = req.body;
  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) return res.status(500).json({ error: err });

    db.query(
      "INSERT INTO users (username, password) VALUES (?, ?)",
      [username, hashedPassword],
      (err) => {
        if (err) return res.status(500).json({ error: err });
        res.status(200).json({ message: "User registered successfully" });
      }
    );
  });
});

app.post("/api/login", (req, res) => {
  const { username, password } = req.body;
  db.query(
    "SELECT * FROM users WHERE username = ?",
    [username],
    (err, result) => {
      if (err) return res.status(500).json({ error: err });
      if (!result.length) return res.status(404).json({ message: "User not found" });

      bcrypt.compare(password, result[0].password, (err, isMatch) => {
        if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

        const token = jwt.sign({ id: result[0].id }, process.env.JWT_SECRET, {
          expiresIn: "1h",
        });

        res.json({ token });
      });
    }
  );
});

// Protecting Routes: Middleware
const authenticate = (req, res, next) => {
  const token = req.headers["authorization"];
  if (!token) return res.status(403).json({ message: "No token provided" });

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ message: "Invalid token" });
    req.userId = decoded.id;
    next();
  });
};

// Board Routes
app.get("/api/boards", authenticate, (req, res) => {
  db.query("SELECT * FROM boards WHERE user_id = ?", [req.userId], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result);
  });
});

app.post("/api/boards", authenticate, (req, res) => {
  const { name } = req.body;
  db.query(
    "INSERT INTO boards (name, user_id) VALUES (?, ?)",
    [name, req.userId],
    (err, result) => {
      if (err) return res.status(500).json({ error: err });
      res.status(200).json({ message: "Board created successfully" });
    }
  );
});

// Task Routes
app.get("/api/board/:boardId/tasks", authenticate, (req, res) => {
  const { boardId } = req.params;
  db.query("SELECT * FROM tasks WHERE board_id = ?", [boardId], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result);
  });
});

app.post("/api/board/:boardId/tasks", authenticate, (req, res) => {
  const { boardId } = req.params;
  const { title, description, status } = req.body;
  db.query(
    "INSERT INTO tasks (title, description, status, board_id) VALUES (?, ?, ?, ?)",
    [title, description, status, boardId],
    (err) => {
      if (err) return res.status(500).json({ error: err });
      res.status(200).json({ message: "Task created successfully" });
    }
  );
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
