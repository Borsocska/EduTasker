import React from "react";
//import "./DashboardPage.css"; // Assuming you will style it similarly
import { useNavigate } from "react-router-dom";

function DashboardPage() {
  const navigate = useNavigate();

  return (
    <div className="dashboard-wrapper">
      <header className="dashboard-header">
        <img id="logo_banner" src="logo_white.svg" alt="Brand logo" />
        <h1>Dashboard</h1>
      </header>
      <div className="dashboard-content">
        <p>Welcome to your Kanban dashboard!</p>
        <button className="btn" onClick={() => navigate("/create-board")}>Create New Board</button>
      </div>
    </div>
  );
}

export default DashboardPage;
